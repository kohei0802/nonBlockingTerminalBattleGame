#include <ncurses.h>
#include <vector>
#include "gameutil.h"


int minigame(WIN *win);
